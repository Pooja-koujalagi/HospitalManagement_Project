package com.example.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.User;
import com.example.model.UserDTO;
import com.example.repository.UserRepository;
import com.example.service.UserService;
import com.example.util.Converter;

@Service
public class UserServiceimpl implements UserService{
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private Converter converter;
	
	
	public UserRepository getUserRepository() {
		return userRepository;
	}

	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	public Converter getConverter() {
		return converter;
	}

	public void setConverter(Converter converter) {
		this.converter = converter;
	}

	//This method is created to save new resource
	public UserDTO saveUser(User user)
	{
		return converter.convertUserToUserDTO(userRepository.save(user));
	}

	//This method is created to fetch all resources
	public List<UserDTO> getAllUsers()
	{
		List<User> users = userRepository.findAll();
		
		List<UserDTO> userDto =new ArrayList<>();
		//convert entity to DTO and store in the List
		for(User user : users)
		{
			userDto.add(converter.convertUserToUserDTO(user));
		}
		return userDto;
	}

	//This method is created to update resource based on id
	public UserDTO updateUser(int id, User user) {
		User existingUser = userRepository.findById(id).get();
		existingUser.setUserName(user.getUserName());
		existingUser.setEmail(user.getEmail());
		existingUser.setPassword(user.getPassword());
		return
	    converter.convertUserToUserDTO(userRepository.save(existingUser));
	}
	
	//This method is created to deactivate resource based on id
	public String deactivateUser(int userId) {
		userRepository.deleteById(userId);
		return "The user's account has been deactivated";
	}
}