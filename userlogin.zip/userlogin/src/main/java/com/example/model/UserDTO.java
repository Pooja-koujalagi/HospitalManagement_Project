package com.example.model;

import lombok.Data;

@Data
public class UserDTO {
    private Integer userId;
    private String userName;
    private String email;  // Changed from 'Email' to 'email' (camelCase)
    private Boolean status; // Added status field to match your request
}
