package com.example.demo.testing;

import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FirstProgram {
	@RequestMapping("/demo")
	@ResponseBody
	
	public String show()
	{
		
		return "Good morning!!!";
	}

}
